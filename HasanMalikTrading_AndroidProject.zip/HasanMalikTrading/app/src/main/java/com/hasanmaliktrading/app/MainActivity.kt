package com.hasanmaliktrading.app
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.TextView
class MainActivity: Activity(){ override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(TextView(this).apply{text="Hasan Malik Trading\n\nLogin successful"; textSize=24f; gravity=Gravity.CENTER; setTextColor(Color.BLACK)})}}
