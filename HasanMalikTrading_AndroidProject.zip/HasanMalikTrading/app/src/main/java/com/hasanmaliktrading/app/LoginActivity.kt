package com.hasanmaliktrading.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.security.MessageDigest

class LoginActivity : Activity() {
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(48,48,48,48) }
        val title = TextView(this).apply { text="Hasan Malik Trading"; textSize=28f; gravity=Gravity.CENTER; setTextColor(Color.BLACK) }
        val user = EditText(this).apply { hint="Username"; singleLine=true }
        val pass = EditText(this).apply { hint="Password"; singleLine=true; inputType=0x81 }
        val login = Button(this).apply { text="LOGIN" }
        val msg = TextView(this).apply { gravity=Gravity.CENTER }
        box.addView(title); box.addView(user); box.addView(pass); box.addView(login); box.addView(msg); setContentView(box)
        login.setOnClickListener {
            if (user.text.toString().trim()=="Hasan" && hash(pass.text.toString())=="012c781f44a0c8f524b733de44b30a39438e7f05cbf9a25db84ad2e206f5cbb5") {
                startActivity(Intent(this, MainActivity::class.java)); finish()
            } else msg.text="Invalid username or password"
        }
    }
}
